
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// functions/postcss.config.mjs
var config = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  }
};
var postcss_config_default = config;
export {
  postcss_config_default as default
};
